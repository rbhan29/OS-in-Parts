#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {

    char *outputfiles[] = {
        "/home/ryan23452/Desktop/q3/cal",
        "/home/ryan23452/Desktop/q3/date",
        "/home/ryan23452/Desktop/q3/uptime"};

    for (int i = 0; i < 3; i++) {
        int pid = fork();
        if (pid < 0) {
            printf("Error, fork failed\n");
            exit(1);
        } else if (pid == 0) {
            char *args[] = {outputfiles[i], NULL};
            execvp(outputfiles[i], args);
        } else {
            wait(NULL);
        }
    }

    return 0;
}
