#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int calculateWeekdayNumber(int month, int year) {
    int weekday, adjustedMonth, adjustedYear;
    int day = 1; // Calculating for the 1st of the month

    // Adjusting for January and February as per Zeller's formula
    if (month < 3) {
        adjustedMonth = month + 12;
        adjustedYear = year - 1;
    } else {
        adjustedMonth = month;
        adjustedYear = year;
    }

    // Zeller's Congruence formula
    weekday = (day + 13 * (adjustedMonth + 1) / 5 + adjustedYear + adjustedYear / 4 - adjustedYear / 100 + adjustedYear / 400) % 7;

    return weekday;
}

void displayCalendar(int month, int year, int startDay) {
    int daysInMonth;

    // Determining the number of days in the month
    if (month == 2) { // February
        if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) {
            daysInMonth = 29; // Leap year
        } else {
            daysInMonth = 28; // Non-leap year
        }
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
        daysInMonth = 30; // Months with 30 days
    } else {
        daysInMonth = 31; // Months with 31 days
    }

    int dayOfMonth = 1;

    // Printing calendar header
    printf("\nSu Mo Tu We Th Fr Sa\n");

    // Printing calendar rows
    for (int week = 0; week < 6; week++) {
        for (int weekday = 0; weekday < 7; weekday++) {
            if (week == 0 && weekday < (startDay + 6) % 7) { // Align the start day of the month
                printf("   ");
            } else if (dayOfMonth <= daysInMonth) {
                printf("%2d ", dayOfMonth);
                dayOfMonth++;
            }
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {
    // Check if the correct number of arguments is provided
    if (argc == 3) {
        int month = atoi(argv[1]);
        int year = atoi(argv[2]);

        // Validate month and year input
        if (month < 1 || month > 12 || year < 1) {
            printf("Invalid month or year\n");
            printf("Usage: ./cal [MM YYYY]\n");
            return 1;
        }

        int startDay = calculateWeekdayNumber(month, year);
        displayCalendar(month, year, startDay);

    // If no arguments are provided, print the calendar for the current month
    } else if (argc == 1) {
        time_t currentTime = time(NULL);
        struct tm *localTime = localtime(&currentTime);
        int month = localTime->tm_mon + 1;
        int year = localTime->tm_year + 1900;
        int startDay = calculateWeekdayNumber(month, year);
        displayCalendar(month, year, startDay);

    // Error message for invalid number of arguments
    } else {
        printf("Invalid number of arguments\n");
        printf("Usage: ./cal [MM YYYY]\n");
    }

    return 0;
}
