#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sysinfo.h>

void prnt_Uptime() {
    struct sysinfo sys_info;
    if (sysinfo(&sys_info) != 0) {
        printf("\nError getting system info\n");
        return;
    }
    int uptime = sys_info.uptime;
    int hours = uptime / 3600;
    int minutes = (uptime % 3600) / 60;
    int seconds = uptime % 60;
    printf("Uptime: %d hours, %d minutes, %d seconds\n", hours, minutes, seconds);
}

int main(int argc, char *argv[]) {
    if (argc == 1) {
        prnt_Uptime();
    } else {
        printf("Invalid \n");
        printf("Usage: ./uptime\n");
    }
    
    return 0;
}
