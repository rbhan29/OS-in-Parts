#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// -i: ISO 8601 format
// -r: RFC 2822 format
// -u: UTC format
// no flag: default local time format

// Function to print the current time in ISO 8601 format
void printISO8601() {
    time_t current_time = time(NULL);   
    struct tm *tminfo = localtime(&current_time); 
    char datestring[40];
    
    // Format time as ISO 8601 with timezone
    strftime(datestring, sizeof(datestring), "%Y-%m-%dT%H:%M:%S%z", tminfo);
    
    // Insert a colon in the timezone offset for ISO 8601 compliance
    datestring[24] = datestring[23];
    datestring[23] = datestring[22];
    datestring[22] = ':';

    printf("%s\n", datestring); 
}

// Function to print the current time in RFC 2822 format
void printRFC2822() {
    time_t current_time = time(NULL); // Getting current time as seconds since epoch
    struct tm *tminfo = localtime(&current_time); // Converting to local time representation
    char datestring[40];
    
    // Format time as RFC 2822
    strftime(datestring, sizeof(datestring), "%a, %d %b %Y %H:%M:%S %z", tminfo);

    printf("%s\n", datestring); 
}

// Function to print the current time in UTC format
void printUTC() {
    time_t current_time = time(NULL); // Getting current time as seconds since epoch
    struct tm *tminfo = gmtime(&current_time); // Converting to UTC time representation
    char datestring[50];
    
    // Format time as UTC with 12-hour clock and AM/PM notation
    strftime(datestring, sizeof(datestring), "%A %d %B %Y %I:%M:%S %p UTC", tminfo);

    printf("%s\n", datestring); 
}

// Function to print the current time in default local format
void printDefault() {
    time_t current_time = time(NULL); // Getting current time as seconds since epoch
    struct tm *tminfo = localtime(&current_time); // Converting to local time representation
    char datestring[50];
    
    // Format time in local time with 12-hour clock and AM/PM notation
    strftime(datestring, sizeof(datestring), "%A %d %B %Y %I:%M:%S %p %Z", tminfo);

    printf("%s\n", datestring); 
}


int main(int argc, char *argv[]) {
    if (argc == 1) {
        printDefault(); // No flag provided, printing default local time
    } else if (argc == 2) {
        // Check for specific flags and call the appropriate function
        if (strcmp(argv[1], "-i") == 0) {
            printISO8601(); // Print time in ISO 8601 format
        } else if (strcmp(argv[1], "-r") == 0) {
            printRFC2822(); //  RFC 2822 format
        } else if (strcmp(argv[1], "-u") == 0) {
            printUTC(); //  UTC format
        } else {
            printf("Invalid flag\n"); 
            printf("Usage: ./date [-i | -r | -u]\n"); // Providing usage instructions
        }
    } else {
        printf("Invalid number of arguments\n"); 
        printf("Usage: ./date [-i | -r | -u]\n"); 
    }

    return 0;
}
